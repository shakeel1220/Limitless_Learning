$(function() {
	var documentEl = $(document),
		fadeElem = $('.fade-scroll');

	documentEl.on('scroll', function() {
		var currScrollPos = documentEl.scrollTop();
		
		fadeElem.each(function() {
			var $this = $(this),
				elemOffsetTop = $this.offset().top;
				elemOffsetTop -= 80;
			if (currScrollPos > elemOffsetTop) $this.css('opacity', 1 - (currScrollPos-elemOffsetTop)/100);
			if (currScrollPos < 20) $this.css('opacity', 1);
		}); 
	});
});